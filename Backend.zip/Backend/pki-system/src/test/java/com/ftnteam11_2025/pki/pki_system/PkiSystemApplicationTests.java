package com.ftnteam11_2025.pki.pki_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PkiSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
