package com.ftnteam11_2025.pki.pki_system.util.exception;

public class BadRequestError extends RuntimeException {
    public BadRequestError(String message) {
        super(message);
    }
}
