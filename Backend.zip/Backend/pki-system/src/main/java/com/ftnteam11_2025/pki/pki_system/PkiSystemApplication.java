package com.ftnteam11_2025.pki.pki_system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PkiSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(PkiSystemApplication.class, args);
	}

}
