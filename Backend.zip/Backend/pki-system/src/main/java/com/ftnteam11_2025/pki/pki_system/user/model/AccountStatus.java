package com.ftnteam11_2025.pki.pki_system.user.model;

public enum AccountStatus {
    ACTIVE,
    DEACTIVATED,
    PENDING,
}
