package com.ftnteam11_2025.pki.pki_system.certificates.service.impl;

import com.ftnteam11_2025.pki.pki_system.certificates.dto.RevokeCertificateDTO;
import com.ftnteam11_2025.pki.pki_system.certificates.service.interfaces.ICertificateRevocationService;

import java.util.UUID;

public class CertificateRevocationService implements ICertificateRevocationService {
    @Override
    public void revokeCertificate(UUID certificateId, RevokeCertificateDTO request) {

    }
}
