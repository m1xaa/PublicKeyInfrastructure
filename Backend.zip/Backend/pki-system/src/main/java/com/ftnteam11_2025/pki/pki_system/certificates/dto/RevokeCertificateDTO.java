package com.ftnteam11_2025.pki.pki_system.certificates.dto;

public record RevokeCertificateDTO(
        RevocationReason reason
) {
}
