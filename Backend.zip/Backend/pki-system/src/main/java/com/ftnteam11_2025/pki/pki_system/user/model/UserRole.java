package com.ftnteam11_2025.pki.pki_system.user.model;

public enum UserRole {
    REGULAR,
    CA,
    ADMINISTRATOR,
}
