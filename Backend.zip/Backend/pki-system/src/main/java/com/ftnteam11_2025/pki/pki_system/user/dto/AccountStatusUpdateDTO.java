package com.ftnteam11_2025.pki.pki_system.user.dto;

import com.ftnteam11_2025.pki.pki_system.user.model.AccountStatus;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AccountStatusUpdateDTO {
    private String email;
}
