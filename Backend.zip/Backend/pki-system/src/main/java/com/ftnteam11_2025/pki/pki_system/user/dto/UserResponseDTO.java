package com.ftnteam11_2025.pki.pki_system.user.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserResponseDTO {
    private Long id;
    private String firstName;
    private String organizationName;
}
