package com.ftnteam11_2025.pki.pki_system.organization.dto;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
public class CreateOrganizationRequestDTO {
    private String name;
}
