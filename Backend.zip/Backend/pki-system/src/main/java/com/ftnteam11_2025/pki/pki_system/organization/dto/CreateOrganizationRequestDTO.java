package com.ftnteam11_2025.pki.pki_system.organization.dto;

import lombok.*;

@Getter
@Setter
public class CreateOrganizationRequestDTO {
    private String name;
}
