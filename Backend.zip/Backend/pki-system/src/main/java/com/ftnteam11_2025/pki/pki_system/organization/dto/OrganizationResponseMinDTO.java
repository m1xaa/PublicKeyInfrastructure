package com.ftnteam11_2025.pki.pki_system.organization.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OrganizationResponseMinDTO {
    private Long id;
    private String name;
}
