package com.ftnteam11_2025.pki.pki_system.certificates.model;

public enum CertificateType {
    RootCA,
    CA,
    EndEntity,
}
