ALTER TABLE certificates
    ADD COLUMN serial_number VARCHAR(255) NOT NULL;